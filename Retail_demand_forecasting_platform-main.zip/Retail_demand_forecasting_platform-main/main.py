def main():
    print("Hello from m5-demand-forecasting-platform!")


if __name__ == "__main__":
    main()
